document.getElementById('interpretButton').addEventListener('click', async () => {
    const dream = document.getElementById('dreamInput').value;
    
    // 调用AI服务API
    const response = await fetch('/api/interpret', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dream }),
    });

    if (response.ok) {
        const data = await response.json();
        document.getElementById('result').textContent = `解梦结果: ${data.interpretation}`;
    } else {
        document.getElementById('result').textContent = '解梦失败，请稍后再试。';
    }
});



