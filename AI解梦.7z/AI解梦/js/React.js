import React, { useState } from 'react';

function DreamInterpreter() {
  const [dream, setDream] = useState('');
  const [result, setResult] = useState('');

  const handleInterpret = async () => {
    const response = await fetch('/api/interpret', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ dream }),
    });
    const data = await response.json();
    setResult(data.interpretation);
  };

  return (
    <div>
      <h1>❀AI花花❀解梦</h1>
      <textarea
        value={dream}
        onChange={(e) => setDream(e.target.value)}
        placeholder="请输入梦境"
        rows="4"
        cols="50"
      />
      <button onClick={handleInterpret}>立即解梦</button>
      {result && <p>解梦结果: {result}</p>}
    </div>
  );
}

export default DreamInterpreter;