
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
app.use(bodyParser.json());

// 提供静态文件服务
app.use(express.static(path.join(__dirname, '../html')));
app.use(express.static(path.join(__dirname, '../css')));
app.use(express.static(path.join(__dirname, '../js')));
app.use(express.static(path.join(__dirname, '../img')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../html', 'hua.html'));
});

app.post('/api/interpret', async (req, res) => {
  const { dream } = req.body;
  const interpretation = await interpretDream(dream);
  res.json({ interpretation });
});

async function interpretDream(dream) {
  return '梦境的详细解读';
}

app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});